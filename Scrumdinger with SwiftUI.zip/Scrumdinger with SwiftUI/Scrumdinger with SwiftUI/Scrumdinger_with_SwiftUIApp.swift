//
//  Scrumdinger_with_SwiftUIApp.swift
//  Scrumdinger with SwiftUI
//
//  Created by Makape Tema on 2023/03/17.
//

import SwiftUI

@main
struct Scrumdinger_with_SwiftUIApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}


